import React from 'react';
import {Route, BrowserRouter} from 'react-router-dom';
import Home from '../templates/home';
import '../../src/static/css/style.css';
import About from '../templates/about';



const Routers = () => {
    return(
        <div>
            <BrowserRouter>
                <Route exact path="/" component={Home}></Route>
                <Route path="/about" component={About}></Route>
            </BrowserRouter>
        </div>
    )
}
export default Routers;