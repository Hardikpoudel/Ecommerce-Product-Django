import React from 'react';
import Header from '../templates/component/header';
import Body from '../templates/pages/body';

const Home_page = () =>{
    return(
        <div>
            <Header/>
            <Body/>
        </div>
    )
}
export default Home_page;