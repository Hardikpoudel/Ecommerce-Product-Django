import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';


const Body = () =>{
    return(
    //         <div>
    //             <div className="mt-2">
    //                <div className="container p-0 text-center">
    //                    <h1 className="fs-4 title">Category</h1>
    //                <div className="row m-0">
    //                    <div className="col p-0 ">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                    <div className="col p-0 ml-3">
    //                        <img src={Image} alt="images" className="w-100 border border-3 rounded-circle"/>
    //                        <p className="fs-6">Shoes</p>
    //                    </div>
    //                </div>
    //                </div>
    //             </div>
    //                {/* <Featured_product/> */}
    //                <h2 className=" fs-4 title">Latest Products</h2>
    //                 <div className="row m-0">
    //                     <div className="col-4">
    //                         <img src={Image}/>
    //                          <h4>Red Printed T-Shirt</h4>
    //                          <div className="rating">
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star-o"></i>
    //                         </div>
    //                         <p>$50.00</p>
    //                      </div>
    //                     <div className="col-4">
    //                          <img src={Image}/>
    //                          <h4>Red Printed T-Shirt</h4>
    //                             <div className="rating">
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star-half-o"></i>
    //                                 <i className="fa fa-star-o"></i>
    //                              </div>
    //                             <p>$50.00</p>
    //                     </div>
    //                   <div className="col-4">
    //                     <img src={Image}/>
    //                         <h4>Red Printed T-Shirt</h4>
    //                         <div className="rating">
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star"></i>
    //                             <i className="fa fa-star-half-o"></i>
    //                         </div>
    //                         <p>$50.00</p>
    //                         </div>
    //                     <div className="col-4">
    //                      <img src={Image}/>
    //                         <h4>Red Printed T-Shirt</h4>
    //                             <div className="rating">
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star"></i>
    //                                 <i className="fa fa-star-o"></i>
    //                             </div>
    //                         <p>$50.00</p>
    //                     </div>
    //                 </div>
    //     <div className="offer">
    //         <div className="small-container">
    //             <div className="row m-0">
    //                 <div className="col-2">
    //                     <img src={Image} className="offer-img"/>
    //                 </div>
    //                 <div className="col-2">
    //                     <p>Exclusively Available On Our Store</p>
    //                     <h1>Smart Band 4</h1>
    //                     <small>The Mi Smart Band 4 features a 39.9% larger (than MI Band3) AMOLED color full-touch display with adjustable brightness, so everything is clear as can be</small>
    //                     <a href="" className="btn">Buy Now&#8594;</a>
    //                 </div>
    //             </div>
    //         </div>
    //     </div>
          
    //       <div className="testimonial">
    //           <div className="small-container">
    //                <div className="row">
    //                    <div className="col-3">
    //                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    //                        <div className="rating">
    //                         <i className="fa fa-star"></i>
    //                         <i className="fa fa-star"></i>
    //                         <i className="fa fa-star"></i>
    //                         <i className="fa fa-star"></i>
    //                         <i className="fa fa-star-o"></i>
    //                         </div>
    //                    </div>
    //                </div>
    //           </div>
    //       </div>
    // </div>
    <div>
        <div>
            <Featured_product/>
        </div>
        <div>
            <Latest_product/>
        </div>
        <div>
            <All_product/>
        </div>
        <div>
            <Exclusive_product/>
        </div>
    </div>
    )
}
const Featured_product = ()=>{
    const [Featured, setFeatured] = useState([]);

         useEffect(()=>{
            axios.get('http://192.168.0.107:8888/api/')
            .then(res=>{
                console.log(res.data);
                setFeatured(res.data);
            })
            .catch(err=>{
                console.log(err);
            })
         },[])
    return(
        <div>
             <h2 className="title">Featured Products</h2>
             <div className="row m-0">
                {
                    Featured.map(lat=>(
                        <div className="col-4" key={lat}>
                            <img src={lat.previewImg} className="w-100"/>
                            <h4>{lat.productName}</h4>
                            <div className="rating">
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star-half-o"></i>
                                <i className="fa fa-star-o"></i>
                            </div>
                            <p>$50.00</p>
                        </div>
                    ))}
                </div>
        </div>
    )
}
const Latest_product = () =>{
    const [Latest, setLatest] = useState([]);

         useEffect(()=>{
            axios.get('http://192.168.0.107:8888/api/')
            .then(res=>{
                console.log(res.data);
                setLatest(res.data);
            })
            .catch(err=>{
                console.log(err);
            })
         },[])
    return(
        <div>
             <h2 className="title">Latest Products</h2>
            <div className="row m-0">
                {
                    Latest.map(fea=>(
                        <div className="col-4" key={fea}>
                            <img src={fea.previewImg} className="w-100"/>
                            <h4>{fea.productName}</h4>
                            <div className="rating">
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star-half-o"></i>
                                <i className="fa fa-star-o"></i>
                            </div>
                            <p>$50.00</p>
                        </div>
                    ))}
            </div>
        </div>
    )
}
const All_product = () =>{
    const [Product, setProduct] = useState([]);

         useEffect(()=>{
            axios.get('http://192.168.0.107:8888/api/')
            .then(res=>{
                console.log(res.data);
                setProduct(res.data);
            })
            .catch(err=>{
                console.log(err);
            })
         },[])
    return(
        <div>
             <h2 className="title">All Products</h2>
            <div className="row m-0">
                {
                    Product.map(fea=>(
                        <div className="col-4" key={fea}>
                            <img src={fea.previewImg} className="w-100"/>
                            <h4>{fea.productName}</h4>
                            <div className="rating">
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star"></i>
                                <i className="fa fa-star-half-o"></i>
                                <i className="fa fa-star-o"></i>
                            </div>
                            <p>$50.00</p>
                        </div>
                    ))}
            </div>
        </div>
    )
}
const Exclusive_product = () =>{
    const [Exproduct, setEXproduct] = useState([]);

         useEffect(()=>{
            axios.get('http://192.168.0.107:8888/api/')
            .then(res=>{
                console.log(res.data);
                setEXproduct(res.data);
            })
            .catch(err=>{
                console.log(err);
            })
         },[])
    return(
        <div>
            <div class="offer">
            <div class="small-container">
            <div class="row">
                {
                    Exproduct.map(fea=>(
                        <div  key={fea}>
                            <div className="col-2">
                        <img src={fea.previewImg} className="w-100"/> 
                        </div>
                        <div className="col-2">
                             <p>Exclusively Available On Our Store</p>
                            <h1>Smart Band 4</h1>
                            <small>The Mi Smart Band 4 features a 39.9% larger (than MI Band3) AMOLED color full-touch display with adjustable brightness, so everything is clear as can be</small>
                            <a href="">Buy Now&#8594;</a>
                      </div>
                        </div>
                    ))}
            </div>
        </div>
        </div>
    </div>
    )
}
export default Body;
