import React from 'react';
import { Link } from 'react-router-dom';
import Image from '../../static/image/cart.png';
import Image1 from '../../static/image/image1.png';
import Logo from '../../static/image/logo.png';


const Header = function(){
    return(
        <div className="header">
            <div className="container">
                <div className="navbar">
                    <div className="logo">
                        <img src={Logo}  width="125px"/>
                    </div>
                    <nav>
                        <ul>
                            <li><Link href="">Home</Link></li>
                            <li><Link href="">Products</Link></li>
                            <li><Link href="">About</Link></li>
                            <li><Link href="">Contact</Link></li>
                            <li><Link href="">Account</Link></li>
                        </ul>
                    <form className="search-form">
                        <input type="text" placeholder="search"/>
                        <button>Search</button>

                    </form>
                    </nav>
                    <img src={Image} width="30px" height="30px"/>
                </div>
                <div className="row m-0">
                    <div className="col-5 p-0 text-left">
                        <h1>Give Your Workout</h1>
                        <h2>A New Style</h2>
                        <p>Success isn't always about greatness, It's about consistency. Consistent <br/>hard work gains success. Greatness will come</p>
                        <div className="text-center col-7 p-0">
                            <button type="button" className="btn text-center"> Explore Now &#8594;</button>
                        </div>
                    </div>
                    <div className="col ms-5 p-0">
                        <img src={Image1} className="w-100"/>
                    </div>
                </div>
            </div>
        </div> 
    )
}
export default Header;